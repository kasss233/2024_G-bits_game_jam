<?xml version="1.0" encoding="UTF-8"?>
<tileset version="1.5" tiledversion="1.7.2" name="Ancient Ruins-wall-8" tilewidth="32" tileheight="32" tilecount="70" columns="10">
 <image source="../Tilesets/wall-8 - 2 tiles tall-transparency.png" width="320" height="224"/>
 <wangsets>
  <wangset name="wall8" type="corner" tile="-1">
   <wangcolor name="" color="#ff0000" tile="-1" probability="1"/>
   <wangtile tileid="1" wangid="0,0,0,1,0,0,0,0"/>
   <wangtile tileid="2" wangid="0,0,0,1,0,1,0,0"/>
   <wangtile tileid="3" wangid="0,0,0,0,0,1,0,0"/>
   <wangtile tileid="10" wangid="0,0,0,1,0,0,0,0"/>
   <wangtile tileid="11" wangid="0,1,0,1,0,1,0,0"/>
   <wangtile tileid="13" wangid="0,0,0,1,0,1,0,1"/>
   <wangtile tileid="14" wangid="0,0,0,0,0,1,0,0"/>
   <wangtile tileid="20" wangid="0,1,0,1,0,0,0,0"/>
   <wangtile tileid="22" wangid="0,1,0,1,0,1,0,1"/>
   <wangtile tileid="24" wangid="0,0,0,0,0,1,0,1"/>
   <wangtile tileid="30" wangid="0,1,0,0,0,0,0,0"/>
   <wangtile tileid="31" wangid="0,1,0,1,0,0,0,1"/>
   <wangtile tileid="33" wangid="0,1,0,0,0,1,0,1"/>
   <wangtile tileid="34" wangid="0,0,0,0,0,0,0,1"/>
   <wangtile tileid="41" wangid="0,1,0,0,0,0,0,0"/>
   <wangtile tileid="42" wangid="0,1,0,0,0,0,0,1"/>
   <wangtile tileid="43" wangid="0,0,0,0,0,0,0,1"/>
  </wangset>
 </wangsets>
</tileset>
